# panel_30_center15 — exact 2^30 BMA results (A100)

- models: 1,073,741,824 (exact, verified)
- PASS1: 115.7 s cumulative (9,277,815 models/s); PASS2: 896 s (this session)
- peak GPU: 1.93 GiB
- posterior mean model size 15.637, mode 15, median 15, 95% CI [15, 18]
- true model: rank 8, PMP 1.881e-02, gap from top 3.2214
- top-mass concentration: top 1: 0.4715, top 10: 0.7267, top 100: 0.9370, top 1000: 0.9946, top 10000: 0.9999

| variable | class | PIP |
|---|---|---|
| x1 | true | 1.0000 |
| x2 | true | 1.0000 |
| x3 | true | 1.0000 |
| x4 | true | 1.0000 |
| x5 | true | 1.0000 |
| x6 | true | 1.0000 |
| x7 | true | 1.0000 |
| x8 | true | 1.0000 |
| x9 | true | 1.0000 |
| x10 | true | 1.0000 |
| x11 | true | 1.0000 |
| x12 | true | 1.0000 |
| x13 | true | 0.9996 |
| x14 | true | 0.9235 |
| x15 | true | 0.0905 |
| x16 | proxy | 0.0309 |
| x17 | proxy | 0.0256 |
| x18 | proxy | 0.0256 |
| x19 | proxy | 0.0921 |
| x20 | proxy | 0.0271 |
| x21 | proxy | 0.0255 |
| x22 | proxy | 0.0478 |
| x23 | proxy | 0.0304 |
| x24 | proxy | 0.1047 |
| x25 | proxy | 0.0471 |
| x26 | proxy | 0.0253 |
| x27 | proxy | 0.0335 |
| x28 | proxy | 0.0354 |
| x29 | proxy | 0.1082 |
| x30 | proxy | 0.9638 |
